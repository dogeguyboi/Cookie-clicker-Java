import {
  Stage as StageBase,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Stage extends StageBase {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("backdrop1", "./Stage/costumes/backdrop1.svg", {
        x: 241.421855,
        y: 195.06597900390625
      })
    ];

    this.sounds = [new Sound("pop", "./Stage/sounds/pop.wav")];

    this.triggers = [];

    this.vars._ = 98;
    this.vars.timesClickedClicker = 2;
    this.vars.timesClickedGramma = 0;
    this.vars.timesClickedFarm = 0;
    this.vars.timesClickedFactory = 0;
    this.vars.clickers = 2;
    this.vars.grammas = 0;
    this.vars.facs = 0;
    this.vars.farms = 0;
    this.vars.clickerPrice = 54;
    this.vars.grammaPrice = 100;
    this.vars.farmPrice = "1,000";
    this.vars.factoryPrice = "12,000";
    this.vars.clickerUpgradePrice = "13,00000";

    this.watchers._ = new Watcher({
      label: "$",
      style: "large",
      visible: true,
      value: () => this.vars._,
      x: 309,
      y: 172
    });
    this.watchers.clickers = new Watcher({
      label: "clickers",
      style: "large",
      visible: true,
      value: () => this.vars.clickers,
      x: 561,
      y: 152
    });
    this.watchers.grammas = new Watcher({
      label: "gramma's",
      style: "large",
      visible: true,
      value: () => this.vars.grammas,
      x: 560,
      y: 66
    });
    this.watchers.facs = new Watcher({
      label: "facs",
      style: "large",
      visible: true,
      value: () => this.vars.facs,
      x: 565,
      y: -122
    });
    this.watchers.farms = new Watcher({
      label: "farms",
      style: "large",
      visible: true,
      value: () => this.vars.farms,
      x: 562,
      y: -18
    });
    this.watchers.clickerPrice = new Watcher({
      label: "clicker price",
      style: "large",
      visible: true,
      value: () => this.vars.clickerPrice,
      x: 644,
      y: -28
    });
    this.watchers.grammaPrice = new Watcher({
      label: "gramma price",
      style: "large",
      visible: true,
      value: () => this.vars.grammaPrice,
      x: 648,
      y: -70
    });
    this.watchers.farmPrice = new Watcher({
      label: "farm price",
      style: "large",
      visible: true,
      value: () => this.vars.farmPrice,
      x: 647,
      y: -111
    });
    this.watchers.factoryPrice = new Watcher({
      label: "factory price",
      style: "large",
      visible: true,
      value: () => this.vars.factoryPrice,
      x: 647,
      y: -156
    });
    this.watchers.clickerUpgradePrice = new Watcher({
      label: "clicker upgrade price",
      style: "large",
      visible: true,
      value: () => this.vars.clickerUpgradePrice,
      x: 248,
      y: -156
    });
  }
}

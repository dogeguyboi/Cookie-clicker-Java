import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Sprite6 extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("costume1", "./Sprite6/costumes/costume1.svg", {
        x: 84.42184499999999,
        y: 30
      })
    ];

    this.sounds = [new Sound("pop", "./Sprite6/sounds/pop.wav")];

    this.triggers = [new Trigger(Trigger.CLICKED, this.whenthisspriteclicked)];
  }

  *whenthisspriteclicked() {
    if (
      this.stage.vars._ > this.stage.vars.factoryPrice ||
      this.stage.vars._ == this.stage.vars.factoryPrice
    ) {
      this.stage.vars._ += 0 - this.stage.vars.factoryPrice;
      this.broadcast("factory!!");
      this.stage.vars.timesClickedFactory += 1;
      this.stage.vars.factoryPrice += 100;
      yield* this.wait(0.2);
    }
  }
}

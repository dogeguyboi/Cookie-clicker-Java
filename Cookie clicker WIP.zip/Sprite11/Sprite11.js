import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Sprite11 extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("costume1", "./Sprite11/costumes/costume1.svg", {
        x: 0,
        y: 0
      }),
      new Costume("mouse", "./Sprite11/costumes/mouse.png", { x: 120, y: 360 })
    ];

    this.sounds = [new Sound("pop", "./Sprite11/sounds/pop.wav")];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked2)
    ];
  }

  *whenGreenFlagClicked() {
    while (true) {
      this.stage.vars.clickers = this.stage.vars.timesClickedClicker;
      yield;
    }
  }

  *whenGreenFlagClicked2() {
    while (true) {
      this.stage.vars.grammas = this.stage.vars.timesClickedGramma;
      yield;
    }
  }
}

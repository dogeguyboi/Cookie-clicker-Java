import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Perfectcookie extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume(
        "PerfectCookie",
        "./Perfectcookie/costumes/PerfectCookie.png",
        { x: 340, y: 340 }
      )
    ];

    this.sounds = [
      new Sound("recording1", "./Perfectcookie/sounds/recording1.wav")
    ];

    this.triggers = [
      new Trigger(Trigger.CLICKED, this.whenthisspriteclicked),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked2)
    ];
  }

  *whenthisspriteclicked() {
    this.stage.vars._ += 1;
    this.size = 66;
    yield* this.wait(0.1);
    this.size = 60;
    this.broadcast("message1");
  }

  *whenGreenFlagClicked() {
    this.stage.vars._ = 0;
    this.size = 60;
  }

  *whenGreenFlagClicked2() {
    this.stage.vars.clickerUpgradePrice = "13,00000";
    this.stage.vars.clickerPrice = 50;
    this.stage.vars.grammaPrice = 100;
    this.stage.vars.farmPrice = "1,000";
    this.stage.vars.factoryPrice = "12,000";
    this.stage.vars.timesClickedGramma = 0;
    this.stage.vars.timesClickedClicker = 0;
    this.stage.vars.timesClickedFactory = 0;
    this.stage.vars.timesClickedFarm = 0;
    while (true) {
      if (this.keyPressed("space")) {
        this.size = 67;
        yield* this.wait(0.1);
        this.size = 60;
        this.broadcast("message1");
        this.stage.vars._ += 1;
      }
      if (this.stage.vars._ < 0) {
        yield* this.sayAndWait("sorry no cheating!", 2);
        /* TODO: Implement stop all */ null;
      }
      yield;
    }
  }
}

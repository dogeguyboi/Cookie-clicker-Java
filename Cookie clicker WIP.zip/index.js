import { Project } from "https://unpkg.com/leopard@^1/dist/index.esm.js";

import Stage from "./Stage/Stage.js";
import Sprite1 from "./Sprite1/Sprite1.js";
import Perfectcookie from "./Perfectcookie/Perfectcookie.js";
import Sprite2 from "./Sprite2/Sprite2.js";
import Sprite4 from "./Sprite4/Sprite4.js";
import Sprite3 from "./Sprite3/Sprite3.js";
import Sprite5 from "./Sprite5/Sprite5.js";
import Sprite6 from "./Sprite6/Sprite6.js";
import Sprite10 from "./Sprite10/Sprite10.js";
import Sprite7 from "./Sprite7/Sprite7.js";
import Sprite8 from "./Sprite8/Sprite8.js";
import Sprite9 from "./Sprite9/Sprite9.js";
import Sprite11 from "./Sprite11/Sprite11.js";
import Sprite12 from "./Sprite12/Sprite12.js";
import Sprite13 from "./Sprite13/Sprite13.js";
import Switch from "./Switch/Switch.js";

const stage = new Stage({ costumeNumber: 1 });

const sprites = {
  Sprite1: new Sprite1({
    x: -141,
    y: -7,
    direction: 90,
    costumeNumber: 1,
    size: 100,
    visible: false,
    layerOrder: 14
  }),
  Perfectcookie: new Perfectcookie({
    x: -139,
    y: -15.999999999999986,
    direction: 90,
    costumeNumber: 1,
    size: 60,
    visible: true,
    layerOrder: 6
  }),
  Sprite2: new Sprite2({
    x: -184.00000000000003,
    y: 161,
    direction: 90,
    costumeNumber: 1,
    size: 100,
    visible: true,
    layerOrder: 1
  }),
  Sprite4: new Sprite4({
    x: 190,
    y: -25,
    direction: 90,
    costumeNumber: 1,
    size: 56.00000000000001,
    visible: true,
    layerOrder: 12
  }),
  Sprite3: new Sprite3({
    x: 190.99999999999997,
    y: -68.00000000000001,
    direction: 90,
    costumeNumber: 1,
    size: 56.00000000000001,
    visible: true,
    layerOrder: 9
  }),
  Sprite5: new Sprite5({
    x: 192,
    y: -109.99999999999997,
    direction: 90,
    costumeNumber: 1,
    size: 56.00000000000001,
    visible: true,
    layerOrder: 10
  }),
  Sprite6: new Sprite6({
    x: 194,
    y: -151,
    direction: 90,
    costumeNumber: 1,
    size: 56.00000000000001,
    visible: true,
    layerOrder: 11
  }),
  Sprite10: new Sprite10({
    x: 36,
    y: 28,
    direction: 90,
    costumeNumber: 1,
    size: 100,
    visible: true,
    layerOrder: 5
  }),
  Sprite7: new Sprite7({
    x: -25.207328784332983,
    y: 15.85856714022369,
    direction: 90,
    costumeNumber: 1,
    size: 100,
    visible: true,
    layerOrder: 4
  }),
  Sprite8: new Sprite8({
    x: -92.41697134452829,
    y: -58.26410716567444,
    direction: 90,
    costumeNumber: 1,
    size: 100,
    visible: true,
    layerOrder: 3
  }),
  Sprite9: new Sprite9({
    x: -50.612981041044904,
    y: -47.48802054557769,
    direction: 90,
    costumeNumber: 1,
    size: 100,
    visible: true,
    layerOrder: 2
  }),
  Sprite11: new Sprite11({
    x: 44.99999942779545,
    y: 83.9999952528216,
    direction: 90,
    costumeNumber: 2,
    size: 50,
    visible: true,
    layerOrder: 7
  }),
  Sprite12: new Sprite12({
    x: 46.999999300638876,
    y: -26.99999533759263,
    direction: 90,
    costumeNumber: 1,
    size: 100,
    visible: true,
    layerOrder: 8
  }),
  Sprite13: new Sprite13({
    x: -181,
    y: -154,
    direction: 90,
    costumeNumber: 1,
    size: 80,
    visible: true,
    layerOrder: 13
  }),
  Switch: new Switch({
    x: 188,
    y: 14,
    direction: 90,
    costumeNumber: 1,
    size: 60,
    visible: true,
    layerOrder: 15
  })
};

const project = new Project(stage, sprites, {
  frameRate: 30 // Set to 60 to make your project run faster
});
export default project;

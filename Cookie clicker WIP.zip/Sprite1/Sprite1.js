import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Sprite1 extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("costume1", "./Sprite1/costumes/costume1.svg", {
        x: 15.777508100891112,
        y: 21.25714500000001
      })
    ];

    this.sounds = [new Sound("pop", "./Sprite1/sounds/pop.wav")];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(Trigger.CLONE_START, this.startAsClone),
      new Trigger(
        Trigger.BROADCAST,
        { name: "message1" },
        this.whenIReceiveMessage1
      ),
      new Trigger(Trigger.CLONE_START, this.startAsClone2)
    ];
  }

  *whenGreenFlagClicked() {
    this.visible = false;
    while (true) {
      this.moveAhead();
      yield;
    }
  }

  *startAsClone() {
    this.moveAhead();
    this.visible = true;
    this.goto(this.mouse.x, this.mouse.y);
    for (let i = 0; i < 50; i++) {
      this.y += 5;
      yield;
    }
    this.deleteThisClone();
  }

  *whenIReceiveMessage1() {
    this.createClone();
  }

  *startAsClone2() {
    this.moveAhead();
    this.visible = true;
    this.goto(this.mouse.x, this.mouse.y);
    for (let i = 0; i < 50; i++) {
      this.effects.ghost += 3;
      yield;
    }
    this.deleteThisClone();
  }
}

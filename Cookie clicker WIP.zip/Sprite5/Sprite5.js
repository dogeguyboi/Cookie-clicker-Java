import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Sprite5 extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("costume1", "./Sprite5/costumes/costume1.svg", {
        x: 84.42184499999999,
        y: 30
      })
    ];

    this.sounds = [new Sound("pop", "./Sprite5/sounds/pop.wav")];

    this.triggers = [new Trigger(Trigger.CLICKED, this.whenthisspriteclicked)];
  }

  *whenthisspriteclicked() {
    if (
      this.stage.vars._ > this.stage.vars.farmPrice ||
      this.stage.vars._ == this.stage.vars.farmPrice
    ) {
      this.broadcast("farm");
      this.stage.vars._ += 0 - this.stage.vars.farmPrice;
      this.stage.vars.farmPrice += 80;
      this.stage.vars.timesClickedFarm += 1;
      yield* this.wait(0.2);
    }
  }
}

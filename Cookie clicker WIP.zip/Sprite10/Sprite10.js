import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Sprite10 extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("costume1", "./Sprite10/costumes/costume1.svg", {
        x: 0,
        y: 0
      })
    ];

    this.sounds = [new Sound("pop", "./Sprite10/sounds/pop.wav")];

    this.triggers = [
      new Trigger(
        Trigger.BROADCAST,
        { name: "clicker!!" },
        this.whenIReceiveClicker
      )
    ];
  }

  *whenIReceiveClicker() {
    while (true) {
      yield* this.wait(1);
      this.stage.vars._ += this.stage.vars.timesClickedClicker * 2;
      yield;
    }
  }
}
